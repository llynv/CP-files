#include "perm.h"

std::vector<int> construct_permutation(long long k)
{
	return {};
}